from django.shortcuts import render,redirect
from .forms import StudentForm
from .models import student
from django.contrib import messages
# Create your views here.
def index(request):
    if request.method=='POST':
        form=StudentForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('index')
        else:
            messages.error(request,'Incorrect Data')
            return redirect('index')
    else:
        form=StudentForm()
        obj=student.objects.all()
        return render(request,'index.html',{'form':form,'studentList':obj})


def deleteStudent(request):
    if request.method=="POST":
        usn=request.POST['usn']
        obj=student.objects.get(usn=usn)
        obj.delete()
        return redirect('index')

def editStudent(request):
    if request.method=="POST":
        usn=request.POST['usn']
        obj=student.objects.get(usn=usn)
        return render(request,'edit.html',{'data':obj})


def editStudentDetails(request):
    if request.method=="POST":
        usn=request.POST['usn']
        obj=student.objects.get(usn=usn)
        obj.name=request.POST['name']
        obj.email=request.POST['email']
        obj.contactNo=request.POST['ph']
        obj.save()
        return redirect('index')
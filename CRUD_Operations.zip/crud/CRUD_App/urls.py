from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('deleteStudent',views.deleteStudent,name='deleteStudent'),
    path('editStudent',views.editStudent,name='editStudent'),
    path('editStudentDetails',views.editStudentDetails,name='editStudentDetails')
]
from django.contrib import admin
from CRUD_App.models import student
# Register your models here.
admin.site.register(student)
from django.db import models as mo


# Create your models here.

class student(mo.Model):
    name = mo.CharField(max_length=15, default='')
    usn = mo.CharField(max_length=12, default='', primary_key=True)
    email = mo.EmailField(max_length=30, default='')
    contactNo = mo.BigIntegerField(max_length=10)

    def __str__(self):
        return self.usn
